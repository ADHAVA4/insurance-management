package librarymngt;

import java.io.*;
import java.time.*;
import java.util.*;
//private static 

class Book {

    protected int id;
    private String title;
    private String author;
    private String publisher;

    public void addBook() {
        Scanner input = new Scanner(System.in);
        id = input.nextInt();
        title = input.next();
    }

    public void viewBook() {
        System.out.println("Id : " + id);
        System.out.println("Title : " + title);

    }

}

class Person {

    protected String name;
    protected String address;
    protected char gender;
    protected String email;
    protected String phno;
    protected String password;

    public void addPerson() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter name and address :");
        name = input.next();
        address = input.next();

    }

}

class Student extends Person {

    public int regno;
    private int nob;
    private String course;
    private int gpa;

    public void addStud() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter student id and course :");
        regno = input.nextInt();
        course = input.next();
        System.out.println("Enter Name : ");
        name = input.next();
        //addPerson();

    }

    public void viewStud() {
        System.out.println("Id : " + regno);
        System.out.println("Name : " + name);

    }
}

class Staff extends Person {

    private int id;
    private String dept;
    private String position;
    private float salary;

    public void addStaff() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter staff id and salary : ");
        id = input.nextInt();
        salary = input.nextFloat();
    }

    public void viewStaff() {
        System.out.println("Id : " + id);
        System.out.println("Name : " + name);

    }
}

class Librarian extends Person {

    private int id;
    private String qualf;
    private int salary;

    public void addLibrarian() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Librarian id and salary : ");
        id = input.nextInt();
        salary = input.nextInt();
        System.out.println("Enter Name: ");
        name = input.next();
    }

    public void viewLibrarian() {
        System.out.println("Id : " + id);
        System.out.println("Name : " + name);

    }
}

/*class BookTxn
{
    private int transId;
    private Date issueDate;
    private String userType;
    private int BookId;
    private int UserId;
    private Date returnDate;
    private Date dueDate;
    private int status;
    
  
}*/
class BookTransaction{

    private int librarianId, userId, bookId;
    private String userType, remarks;
    private Date dueDate, returnDate;
    private float fine;
    private int transactionId, status;
    LocalDate issueDate = LocalDate.now();

    public void issueBook(int bkid,int uid,String Utype) {
        bookId=bkid;
        userId=uid;
        userType=Utype;
        Random random = new Random();
        Scanner input = new Scanner(System.in);
        System.out.println("Your issue date is " + issueDate);
        status = 1;
        transactionId = random.nextInt(5000);
        System.out.println("Successful, Your Transaction Id is " + transactionId);
    }

    public void returnBook() {
        System.out.println("Your transaction id is " + transactionId);
        if (status == 1) {
            status = 0;
            System.out.println("Your book is returned successfully");
        } else {
            System.out.println("You have already returned the book");
        }
    }

    public void viewTransaction() {
        System.out.println(userType + "\n " + userId + "\n " + bookId + "\n " + issueDate + "\n " + transactionId);
        if (status == 1) {
            System.out.println("Not returned");
        } else {
            System.out.println("Returned");
        }
    }
    /*   public static void main(String args[])
    {
        BookTransaction book=new BookTransaction();        
        book.issueBook();
        book.returnBook();
        book.viewTransaction();
    }*/
}

public class LibraryMngt {

    public static void main(String[] args) {
        int st = 1, ch, i = 0, j = 0, k = 0, l = 0, choice;
        Student[] Stud = new Student[3];
        Staff[] Stf = new Staff[3];
        Librarian[] Librn = new Librarian[3];
        Book[] Bk = new Book[3];
        BookTransaction Bt=new BookTransaction();

        while (st == 1) {
            System.out.println("LIBRARY MANAGEMENT");
            System.out.println("1. Student");
            System.out.println("2. Staff");
            System.out.println("3. Librarian");
            System.out.println("4. Book Catalogue");
            System.out.println("5. Book Transaction");
            System.out.println("6. View Transaction");

            Scanner input = new Scanner(System.in);

            ch = input.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("1. Registration\n2. View");
                    choice = input.nextInt();
                    switch (choice) {
                        case 1:
                            Stud[i] = new Student();
                            Stud[i].addStud();
                            i++;
                            break;
                        case 2:
                            System.out.println("\n\nYou are viewing student\n\n");
                            for (int a = 0; a < 3; a++) {
                                Stud[a].viewStud();
                            }
                            break;
                        default:
                            break;

                    }

                    break;

                case 2:
                    System.out.println("1. Registration\n2. View");
                    choice = input.nextInt();
                    switch (choice) {
                        case 1:
                            Stf[j] = new Staff();
                            Stf[j].addStaff();
                            j++;
                            break;
                        case 2:
                            System.out.println("\n\nYou are viewing staff details\n\n");
                            for (int a = 0; a < 3; a++) {
                                Stf[a].viewStaff();
                            }
                            break;
                        default:
                            break;

                    }

                    break;
                case 3:
                    System.out.println("1. Registration\n2. View");
                    choice = input.nextInt();
                    switch (choice) {
                        case 1:
                            Librn[k] = new Librarian();
                            Librn[k].addLibrarian();
                            k++;
                            break;
                        case 2:
                            System.out.println("\n\nYou are viewing Librarian details\n\n");
                            for (int a = 0; a < 3; a++) {
                                Librn[a].viewLibrarian();
                            }
                            break;
                        default:
                            break;

                    }

                    break;
                case 4:
                    System.out.println("1. Book Registration\n2. View");
                    choice = input.nextInt();
                    switch (choice) {
                        case 1:
                            Bk[l] = new Book();
                            Bk[l].addBook();
                            l++;
                            break;
                        case 2:
                            System.out.println("\n\nYou are viewing Book details\n\n");
                            for (int a = 0; a < 3; a++) {
                                Bk[a].viewBook();
                            }
                            break;
                        default:
                            break;

                    }

                    break;

                case 5:
                    
                    System.out.println("Enter User Type: \n1. Student\n2. Staff\n3. Librarian");
                    int Utype = input.nextInt();
                    
                    switch (Utype) 
                    {
                        case 1:
                           
                            System.out.println("Enter Regno : ");
                            int reg = input.nextInt();
                            for (int a = 0; a < 3; a++) 
                            {
                                if (reg == Stud[a].regno) 
                                {
                                    System.out.println("Enter book Id : ");
                                    int bookId = input.nextInt();
                                    for(int b=0;b<3;b++)
                                    if (bookId == Bk[b].id) 
                                    {
                                        Bt.issueBook(bookId,reg,"Student");
                                        break;
                                    }
                                break;
                                }
                            }
                    }
                    break;
                case 6:
                    Bt.viewTransaction();
                    break;
                default:
                    System.out.println("The program ends");
                    System.exit(0);

            }
        }
    }

}
