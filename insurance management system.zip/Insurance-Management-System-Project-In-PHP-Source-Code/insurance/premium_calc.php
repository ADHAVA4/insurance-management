
<script type="text/javascript">
function checnum(as)
{
var a = as.value;
for(var x=0; x<a.length; x++)
{
var ff = a[x];
if(isNaN(a) || ff==" ")
{
a = a.substring(0,(a.length-1));
as.value = a;
}}}
function getCheckedValue( groupName ) {
var radios = document.getElementsByName( groupName );
for( i = 0; i < radios.length; i++ ) {
if( radios[i].checked ) {
return radios[i].value;
}
}
return null;
}
function tqe_perc()
{
	var premium=0;
var totamount=0;
var p1= document.getElementById("amount").value;
var age1=document.getElementById("age").value;
if(age1=="")
document.getElementById("err_msg").innerHTML="<font color='red'><b>Enter the current age</b></font>";
else if(age1>50)
document.getElementById("err_msg").innerHTML="<font color='red'><b>Age limit attained</b></font>";
else if(p1=="")
document.getElementById("err_msg").innerHTML="<font color='red'><b>Enter the premium payable</b></font>"
else
{
document.getElementById("err_msg").innerHTML="";
var p= parseFloat(p1);
var age= parseFloat(age1);
var y= parseFloat(getCheckedValue("year"));
var t=getCheckedValue("t")
if(p==""||age==""||y=="")
{
alert("enter the amount,interstand year");
}
else
{
if(t=="Yearly")
{
totamount=(y*p);
premium=(p*0.1);
document.getElementById("r1").value=totamount;
document.getElementById("r2").value=premium;
}
else
{
totamount=((p/12)*y);
premium=(((p/12)/12)*0.1);
document.getElementById("r1").value=totamount;
document.getElementById("r2").value=premium;
}
}
}

//alert(totamount+(p*y*6/100));
}
</script>
<html>
<head>
<title>Life Insurance Calculator Script</title>
<style>


.btn{
	background-color: #4CAF50;
	float: right;
	color:white;
	text-decoration:none;	
}

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
	margin-left:0%;
	font-size:110%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
.dis {
	pointer-events: none;
	cursor: default;
	color:#595959;
}
</style>
<style>
input[type=text], select {
    width: 20%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

p {
  display: flex;
  gap: 10px;
}

input[type="button"],
input[type="reset"] {
  background-color: rgb(4, 18, 99);
  color: #fff;
  padding: 15px 20px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  width: 50%;
}

input[type="button"]:hover {
  background-color: rgb(66, 6, 143)


input[type=reset]:hover {
    background-color: #45a049;
}


table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
.searchBar {
	float: auto;
	cursor: pointer;
	width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
	
}


</style>
  <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />


</head>
<div id="calculator" align=center>
<form name=first>
<?php include 'header.php'; 
?>
<div id="page-wrapper">
            
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Life Insurance Monthly/Yearly Premium Payment Calculation
						
						</h1>
                    </div>
                </div>
			
<table align=center border=0 cellpadding=1 cellspacing=1 id=tqe_calc>
<tr><td colspan=2 align='center'> <div id='err_msg'></div> </td></tr>
<tr><td align=left><center>Age:</td><td><input type=text id=age onkeyup=checnum(this)></td></tr>
<br><tr><td colspan=2>
</td></tr>
<tr><td align=left><center>Annual salary:</td><td><input type=text id=amount onkeyup=checnum(this) size="10"><br><br><input type=radio name=t value=Monthly>Monthly&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=radio name=t value=Yearly checked>Yearly</td></tr>
<tr><td colspan=2>
<tr><td align=left><center>For policy term of</td><td><div id=y><input type=radio name=year value=10 checked>10-Year &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name=year value=15>15-Year&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=radio name=year value=20>20-year</div></td></tr>
<tr><td colspan=2>
</td></tr>
<tr><td align=center colspan=2> <br><center><p><input type=button value='Calculate'  onclick=tqe_perc() >
<input type=reset value='Reset'></center> </td></tr></p>
<tr><td align=left><center>Fund Amount:</td><td><input type=text id=r1 disabled></td></tr>
<tr><td align=left><center>Premium Payable:</td><td><input type=text id=r2 disabled></td></tr>
<tr><td colspan=2>
</td></tr>
</table></form></div>
</html>

